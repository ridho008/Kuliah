-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2021 at 09:49 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `water-part-native-135`
--

-- --------------------------------------------------------

--
-- Table structure for table `pengunjung135`
--

CREATE TABLE `pengunjung135` (
  `id_pengunjung135` int(11) NOT NULL,
  `nama_pengunjung135` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengunjung135`
--

INSERT INTO `pengunjung135` (`id_pengunjung135`, `nama_pengunjung135`) VALUES
(1, 'Ridho Surya'),
(3, 'Hasan Saputra'),
(6, 'Budi Setiawan');

-- --------------------------------------------------------

--
-- Table structure for table `tiket135`
--

CREATE TABLE `tiket135` (
  `id_tiket135` int(11) NOT NULL,
  `nama_tiket135` varchar(100) NOT NULL,
  `harga135` int(11) NOT NULL,
  `deskripsi135` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tiket135`
--

INSERT INTO `tiket135` (`id_tiket135`, `nama_tiket135`, `harga135`, `deskripsi135`) VALUES
(1, 'Regular', 30000, 'Standart'),
(2, 'VIP', 100000, 'Cemilan, Minum, Kursi Nyaman');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi135`
--

CREATE TABLE `transaksi135` (
  `id_transaksi135` int(11) NOT NULL,
  `id_tiket135` int(11) DEFAULT NULL,
  `id_pengunjung135` int(11) DEFAULT NULL,
  `jml_tiket135` int(11) DEFAULT NULL,
  `tgl_transaksi135` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi135`
--

INSERT INTO `transaksi135` (`id_transaksi135`, `id_tiket135`, `id_pengunjung135`, `jml_tiket135`, `tgl_transaksi135`) VALUES
(2, 1, 1, 10, '2021-04-29 15:40:10'),
(3, 2, 3, 5, '2021-04-07 15:43:53');

-- --------------------------------------------------------

--
-- Table structure for table `user135`
--

CREATE TABLE `user135` (
  `id_user135` int(11) NOT NULL,
  `username135` varchar(20) DEFAULT NULL,
  `password135` varchar(255) DEFAULT NULL,
  `role135` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user135`
--

INSERT INTO `user135` (`id_user135`, `username135`, `password135`, `role135`) VALUES
(1, 'ridho008', 'ridho008', 0),
(2, 'budi', 'budi', 1),
(3, 'hasan', 'hasan', 2),
(4, 'direktur', 'coba', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pengunjung135`
--
ALTER TABLE `pengunjung135`
  ADD PRIMARY KEY (`id_pengunjung135`);

--
-- Indexes for table `tiket135`
--
ALTER TABLE `tiket135`
  ADD PRIMARY KEY (`id_tiket135`);

--
-- Indexes for table `transaksi135`
--
ALTER TABLE `transaksi135`
  ADD PRIMARY KEY (`id_transaksi135`);

--
-- Indexes for table `user135`
--
ALTER TABLE `user135`
  ADD PRIMARY KEY (`id_user135`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengunjung135`
--
ALTER TABLE `pengunjung135`
  MODIFY `id_pengunjung135` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tiket135`
--
ALTER TABLE `tiket135`
  MODIFY `id_tiket135` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transaksi135`
--
ALTER TABLE `transaksi135`
  MODIFY `id_transaksi135` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user135`
--
ALTER TABLE `user135`
  MODIFY `id_user135` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
