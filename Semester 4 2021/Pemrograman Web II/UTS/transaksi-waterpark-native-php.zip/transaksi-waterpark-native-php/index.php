<?php 
session_start();
// var_dump($_SESSION);
if(!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit;
}
require 'config/functions.php';
$page = @$_GET['page'];
$act = @$_GET['act'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Transaksi Tiket WaterPark</title>
   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
   
   <!-- Navbar -->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="index.php">Transaksi Tiket WaterPark</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav mr-auto">
            <a class="nav-link<?= (!$_GET) ? ' active' : '' ?>" href="index.php">Home</a>
            <!-- Admin -->
            <?php if($_SESSION['role'] == 0) : ?>
            <a class="nav-link<?= ($_GET['page'] == 'user') ? ' active' : '' ?>" href="?page=user">User</a>
            <a class="nav-link<?= ($_GET['page'] == 'tiket') ? ' active' : '' ?>" href="?page=tiket">Tiket</a>
            <a class="nav-link<?= ($_GET['page'] == 'pengunjung') ? ' active' : '' ?>" href="?page=pengunjung">Pengunjung</a>
            <a class="nav-link<?= ($_GET['page'] == 'transaksi') ? ' active' : '' ?>" href="?page=transaksi">Transaksi</a>
            <a class="nav-link<?= ($_GET['page'] == 'laporan') ? ' active' : '' ?>" href="?page=laporan">Laporan</a>
            <a class="nav-link<?= ($_GET['page'] == 'filterLaporan') ? ' active' : '' ?>" href="?page=filterLaporan">Filter Laporan</a>
            <?php endif; ?>

            <!-- Directur -->
            <?php if($_SESSION['role'] == 1) : ?>
            <a class="nav-link<?= ($_GET['page'] == 'laporan') ? ' active' : '' ?>" href="?page=laporan">Laporan</a>
            <a class="nav-link<?= ($_GET['page'] == 'filterLaporan') ? ' active' : '' ?>" href="?page=filterLaporan">Filter Laporan</a>
            <?php endif; ?>

            <!-- Kasir -->
            <?php if($_SESSION['role'] == 2) : ?>
            <a class="nav-link<?= ($_GET['page'] == 'transaksi') ? ' active' : '' ?>" href="?page=transaksi">Transaksi</a>
            <a class="nav-link<?= ($_GET['page'] == 'laporan') ? ' active' : '' ?>" href="?page=laporan">Laporan</a>
            <a class="nav-link<?= ($_GET['page'] == 'filterLaporan') ? ' active' : '' ?>" href="?page=filterLaporan">Filter Laporan</a>
            <?php endif; ?>
          </div>
          <div class="navbar-nav">
            <a class="nav-link" href="logout.php">Logout</a>
          </div>
        </div>
     </div>
   </nav>
   <!-- /Navbar -->

   <div class="container mt-4">
      <div class="row">
         <div class="col-md-12">
            <?php 
            if(isset($page)) {
               if($page == 'tiket') {
                  if($act == '') {
                     require 'page/tiket/index.php';
                  } else if($act == 'add') {
                     require 'page/tiket/create.php';
                  } else if($act == 'update') {
                     require 'page/tiket/update.php';
                  } else if($act == 'delete') {
                     require 'page/tiket/delete.php';
                  }
               } else if($page == 'pengunjung') {
                  if($act == '') {
                     require 'page/pengunjung/index.php';
                  } else if($act == 'add') {
                     require 'page/pengunjung/create.php';
                  } else if($act == 'update') {
                     require 'page/pengunjung/update.php';
                  } else if($act == 'delete') {
                     require 'page/pengunjung/delete.php';
                  }
               } else if($page == 'transaksi') {
                  if($act == '') {
                     require 'page/transaksi/index.php';
                  } else if($act == 'add') {
                     require 'page/transaksi/create.php';
                  } else if($act == 'update') {
                     require 'page/transaksi/update.php';
                  } else if($act == 'delete') {
                     require 'page/transaksi/delete.php';
                  }
               } else if($page == 'laporan') {
                  if($act == '') {
                     require 'page/laporan/laporan.php';
                  }
               } else if($page == 'filterLaporan') {
                  if($act == '') {
                     require 'page/laporan/filterLaporan.php';
                  }
               } else if($page == 'user') {
                  if($act == '') {
                     require 'page/user/index.php';
                  } else if($act == 'add') {
                     require 'page/user/create.php';
                  } else if($act == 'update') {
                     require 'page/user/update.php';
                  } else if($act == 'delete') {
                     require 'page/user/delete.php';
                  }
                }
            } else { ?>
              <div class="jumbotron">
                <h1 class="display-4">Selamat Datang! <?= $_SESSION['nama']; ?></h1>
                <p class="lead">Aplikasi Transaksi WaterPark Sederhana Menggunakan PHP 7</p>
                <hr class="my-4">
                <?php 
                if($_SESSION['role'] == 0) {
                  $nama = 'Administrator';
                } elseif ($_SESSION['role'] == 1) {
                  $nama = 'Direktur Utama';
                } elseif ($_SESSION['role'] == 2) {
                  $nama = 'Kasir';
                }

                ?>
                <h5>Anda Login Sebagai <span class="badge badge-info"><?= $nama; ?></span></h5>
              </div>
            <?php
            }
            ?>
         </div>
      </div>
   </div>

   <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>