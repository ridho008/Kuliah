<?php 
if(isset($_POST['add'])) {
   if(storeTiket($_POST) > 0) {
      echo "<script>alert('Data Tiket Berhasil Ditambahkan.');window.location='?page=tiket';</script>";
   } else {
      echo "<script>alert('Data Tiket Gagal Ditambahkan.');window.location='?page=tiket&act=add';</script>";
   }
}
?>
<h1>Tambah Tiket</h1>
<form action="" method="post">
   <div class="form-group">
      <label for="tiket">Nama Tiket</label>
      <input type="text" name="tiket" id="tiket" class="form-control" required="">
   </div>
   <div class="form-group">
      <label for="harga">Harga</label>
      <input type="number" name="harga" id="harga" class="form-control" required="">
   </div>
   <div class="form-group">
      <label for="deskripsi">Deskripsi</label>
      <textarea name="deskripsi" id="deskripsi" class="form-control" placeholder="deskripsi..."></textarea>
   </div>
   <div class="form-group">
      <button type="submit" name="add" class="btn btn-primary btn-xs">Tambah</button>
   </div>
</form>