<?php 
$tiket = query("SELECT * FROM tiket135 ORDER BY id_tiket135 DESC");
?>
<h1>Data Tiket</h1>
<a href="?page=tiket&act=add" class="btn btn-primary mb-2">Tambah Tiket</a>
<div class="table-responsive">
   <table class="table table-bordered table-striped">
      <thead class="bg-dark text-light">
         <tr>
            <th>No</th>
            <th>Tiket</th>
            <th>Harga</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
         </tr>
      </thead>
      <tbody>
         <?php $no = 1; foreach($tiket as $p) : ?>
         <tr>
            <td><?= $no++; ?></td>
            <td><?= $p["nama_tiket135"]; ?></td>
            <td><?= number_format($p["harga135"], 0, ',', '.'); ?></td>
            <td><?= $p["deskripsi135"]; ?></td>
            <td>
               <a href="?page=tiket&act=update&id=<?= $p["id_tiket135"]; ?>" class="btn btn-info btn-xs">Edit</a>
               <a href="?page=tiket&act=delete&id=<?= $p["id_tiket135"]; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin Hapus <?= $p["nama_tiket"] ?>?')">Hapus</a>
            </td>
         </tr>
         <?php endforeach; ?>
      </tbody>
   </table>
</div>