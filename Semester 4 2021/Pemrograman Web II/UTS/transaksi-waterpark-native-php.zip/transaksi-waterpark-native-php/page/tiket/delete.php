<?php 
$id_tiket = $_GET['id'];
$tiket = mysqli_query($con, "DELETE FROM tiket135 WHERE id_tiket135 = '$id_tiket'");
if($tiket) {
      echo "<script>alert('Data Tiket Berhasil Dihapus.');window.location='?page=tiket';</script>";
   } else {
      echo "<script>alert('Data Tiket Gagal Dihapus.');window.location='?page=tiket';</script>";
   }
?>