<?php 
$id_tiket = $_GET['id'];
$tiket = query("SELECT * FROM tiket135 WHERE id_tiket135 = '$id_tiket'")[0];
if(isset($_POST['update'])) {
   if(updateTiket($_POST) > 0) {
      echo "<script>alert('Data Tiket Berhasil Diubah.');window.location='?page=tiket';</script>";
   } else {
      echo "<script>alert('Data Tiket Gagal Diubah.');window.location='?page=tiket&act=add';</script>";
   }
}
?>
<h1>Edit Tiket <?= $tiket["nama_tiket135"]; ?></h1>
<form action="" method="post">
   <input type="hidden" name="id_tiket" value="<?= $tiket["id_tiket135"]; ?>">
   <div class="form-group">
      <label for="tiket">Nama Tiket</label>
      <input type="text" name="tiket" id="tiket" class="form-control" required="" value="<?= $tiket["nama_tiket135"]; ?>">
   </div>
   <div class="form-group">
      <label for="harga">Harga</label>
      <input type="number" name="harga" id="harga" class="form-control" required="" value="<?= $tiket["harga135"]; ?>">
   </div>
   <div class="form-group">
      <label for="deskripsi">Deskripsi</label>
      <textarea name="deskripsi" id="deskripsi" class="form-control" placeholder="deskripsi..."><?= $tiket["deskripsi135"]; ?></textarea>
   </div>
   <div class="form-group">
      <button type="submit" name="update" class="btn btn-primary btn-xs">Ubah</button>
   </div>
</form>