<?php 
$id_transaksi = $_GET['id'];
$transaksi = query("SELECT * FROM transaksi135 WHERE id_transaksi135 = '$id_transaksi'")[0];
$pengunjung = query("SELECT * FROM pengunjung135 ORDER BY nama_pengunjung135 ASC");
$tiket = query("SELECT * FROM tiket135 ORDER BY nama_tiket135 ASC");
// var_dump($barang); die;
if(isset($_POST['update'])) {
   if(updateTransaksi($_POST) > 0) {
      echo "<script>alert('Data Transaksi Berhasil Diubah.');window.location='?page=transaksi';</script>";
   } else {
      echo "<script>alert('Data Transaksi Gagal Diubah.');window.location='?page=transaksi&act=add';</script>";
   }
}
?>
<h1>Edit Transaksi</h1>
<form action="" method="post">
   <input type="hidden" name="id_transaksi" value="<?= $transaksi["id_transaksi135"]; ?>">
   <div class="form-group">
      <label for="pengunjung">Nama Pengunjung</label>
      <select name="pengunjung" id="pengunjung" class="form-control">
         <option value="">-- Pilih Pengunjung --</option>
         <?php foreach($pengunjung as $t) : ?>
            <?php if($t['id_pengunjung135'] == $transaksi['id_pengunjung135']) : ?>
            <option value="<?= $t['id_pengunjung135']; ?>" selected><?= $t['nama_pengunjung135']; ?></option>
            <?php else: ?>
            <option value="<?= $t['id_pengunjung135']; ?>"><?= $t['nama_pengunjung135']; ?></option>
         <?php endif; ?>
         <?php endforeach; ?>
      </select>
   </div>
   <div class="form-group">
      <label for="tiket">Tiket</label>
      <select name="tiket" id="tiket" class="form-control">
         <option value="">-- Pilih Tiket --</option>
         <?php foreach($tiket as $t) : ?>
            <?php if($t['id_tiket135'] == $transaksi['id_tiket135']) : ?>
            <option value="<?= $t['id_tiket135']; ?>" selected><?= $t['nama_tiket135']; ?></option>
            <?php else: ?>
            <option value="<?= $t['id_tiket135']; ?>"><?= $t['nama_tiket135']; ?></option>
            <?php endif; ?>
         <?php endforeach; ?>
      </select>
   </div>
   <div class="form-group">
      <label for="jml_tiket">Jumlah Tiket</label>
      <select name="jml_tiket" id="jml_tiket" class="form-control">
         <option value="">-- Pilih Jumlah\Tiket --</option>
         <?php for($i = 1; $i <= 30; $i++) : ?>
            <?php if($i == $transaksi['jml_tiket135']) : ?>
            <option value="<?= $i; ?>" selected><?= $i; ?> Tiket</option>
            <?php else: ?>
            <option value="<?= $i; ?>"><?= $i; ?> Tiket</option>
            <?php endif; ?>
         <?php endfor; ?>
      </select>
   </div>
   <div class="form-group">
      <button type="submit" name="update" class="btn btn-primary btn-xs">Ubah</button>
   </div>
</form>