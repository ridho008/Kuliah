<?php 

$transaksi = query("SELECT * FROM transaksi135 JOIN pengunjung135 ON transaksi135.id_pengunjung135 = pengunjung135.id_pengunjung135 JOIN tiket135 ON tiket135.id_tiket135 = transaksi135.id_tiket135 ORDER BY transaksi135.id_tiket135 DESC");

?>
<h1>Data Transaksi</h1>
<a href="?page=transaksi&act=add" class="btn btn-primary mb-2">Tambah Transaksi</a>
<div class="table-responsive">
   <table class="table table-bordered table-striped">
      <thead class="bg-dark text-light">
         <tr>
            <th>No</th>
            <th>Pengunjung</th>
            <th>Tiket</th>
            <th>Harga/Tiket</th>
            <th>Jumlah Beli</th>
            <th>Total Barang</th>
            <th>Diskon</th>
            <th>Total</th>
            <th>Aksi</th>
         </tr>
      </thead>
      <tbody>
         <?php $no = 1; foreach($transaksi as $t) : ?>
         <?php 
         $diskon10 = 10;
         $diskon20 = 20;
         ?>
         <tr>
            <td><?= $no++; ?></td>
            <td><?= $t["nama_pengunjung135"]; ?></td>
            <td><?= $t["nama_tiket135"]; ?></td>
            <td><?= number_format($t["harga135"],0 ,',', '.'); ?></td>
            <td><?= $t["jml_tiket135"]; ?> Tiket</td>
            <td><?= number_format($t["jml_tiket135"] * $t["harga135"],0 ,',', '.') ?></td>
            <td>
               <?php if($t["jml_tiket135"] >= 10 && $t["jml_tiket135"] <= 19) : ?>
                  <?php $totDiskon = ($diskon10 / 100) * $t["jml_tiket135"] * $t["harga135"]; ?>
                  <?= number_format($totDiskon, 0, ',', '.') . ' 10%'; ?>
                  <?php elseif($t["jml_tiket135"] <= 9) : ?>
                     <span class="badge badge-info">Maksimal 10Tiket mendapatkan diskon.</span>
               <?php endif; ?>

               <?php if($t["jml_tiket135"] >= 20) : ?>
                  <?php $totDiskon = ($diskon20 / 100) * $t["jml_tiket135"] * $t["harga135"]; ?>
                  <?= number_format($totDiskon, 0, ',', '.') . ' 20%'; ?>
               <?php endif; ?>
            </td>
            <td>
               <?php if($t["jml_tiket135"] >= 10 || $t["jml_tiket135"] <= 19 || $t["jml_tiket135"] >= 20) : ?>
               <?= number_format(abs($totDiskon - ($t["jml_tiket135"] * $t["harga135"])),0 ,',', '.') ?>
               <?php elseif($t["jml_tiket135"] >= 0 || $t["jml_tiket135"] <= 9): ?>
                  <?= $t["jml_tiket135"] * $t["harga135"] ?>
               <?php endif; ?>
            </td>
            <td>
               <a href="?page=transaksi&act=update&id=<?= $t["id_transaksi135"]; ?>" class="btn btn-info btn-xs">Edit</a>
               <a href="?page=transaksi&act=delete&id=<?= $t["id_transaksi135"]; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin Hapus <?= $p["nama_pengunjung"] ?>?')">Hapus</a>
            </td>
         </tr>
         <?php endforeach; ?>
      </tbody>
   </table>
</div>