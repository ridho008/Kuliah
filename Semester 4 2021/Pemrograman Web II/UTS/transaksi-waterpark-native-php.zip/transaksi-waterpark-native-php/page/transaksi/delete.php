<?php 
$id_transaksi = $_GET['id'];
$transaksi = mysqli_query($con, "DELETE FROM transaksi135 WHERE id_transaksi135 = '$id_transaksi'");
if($transaksi) {
      echo "<script>alert('Data Transaksi Berhasil Dihapus.');window.location='?page=transaksi';</script>";
   } else {
      echo "<script>alert('Data Transaksi Gagal Dihapus.');window.location='?page=transaksi';</script>";
   }
?>