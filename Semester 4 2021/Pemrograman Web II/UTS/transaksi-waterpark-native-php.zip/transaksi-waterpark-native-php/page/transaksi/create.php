<?php 
$pengunjung = query("SELECT * FROM pengunjung135 ORDER BY nama_pengunjung135 ASC");
$tiket = query("SELECT * FROM tiket135 ORDER BY nama_tiket135 ASC");

if(isset($_POST['add'])) {
   if(storeTransaksi($_POST) > 0) {
      echo "<script>alert('Data Transaksi Berhasil Ditambahkan.');window.location='?page=transaksi';</script>";
   } else {
      echo "<script>alert('Data Transaksi Gagal Ditambahkan.');window.location='?page=transaksi&act=add';</script>";
   }
}
?>
<h1>Tambah Transaksi</h1>
<form action="" method="post">
   <div class="form-group">
      <label for="pengunjung">Nama Pengunjung</label>
      <select name="pengunjung" id="pengunjung" class="form-control">
         <option value="">-- Pilih Pengunjung --</option>
         <?php foreach($pengunjung as $t) : ?>
            <option value="<?= $t['id_pengunjung135']; ?>"><?= $t['nama_pengunjung135']; ?></option>
         <?php endforeach; ?>
      </select>
   </div>
   <div class="form-group">
      <label for="tiket">Tiket</label>
      <select name="tiket" id="tiket" class="form-control">
         <option value="">-- Pilih Tiket --</option>
         <?php foreach($tiket as $t) : ?>
            <option value="<?= $t['id_tiket135']; ?>"><?= $t['nama_tiket135']; ?></option>
         <?php endforeach; ?>
      </select>
   </div>
   <div class="form-group">
      <label for="jml_tiket">Jumlah Tiket</label>
      <select name="jml_tiket" id="jml_tiket" class="form-control">
         <option value="">-- Pilih Tiket --</option>
         <?php for($i = 1; $i <= 30; $i++) : ?>
            <option value="<?= $i; ?>"><?= $i; ?> Kg</option>
         <?php endfor; ?>
      </select>
   </div>
   <div class="form-group">
      <button type="submit" name="add" class="btn btn-primary btn-xs">Tambah</button>
   </div>
</form>