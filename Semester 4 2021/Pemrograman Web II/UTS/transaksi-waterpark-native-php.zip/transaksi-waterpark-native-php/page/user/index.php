<?php 
$user = query("SELECT * FROM user135 ORDER BY id_user135 DESC");
?>
<h1>User</h1>
<a href="?page=user&act=add" class="btn btn-primary mb-2">Tambah User</a>
<div class="table-responsive">
   <table class="table table-bordered table-striped">
      <thead class="bg-dark text-light">
         <tr>
            <th>No</th>
            <th>Username</th>
            <th>Akses</th>
            <th>Aksi</th>
         </tr>
      </thead>
      <tbody>
         <?php $no = 1; foreach($user as $b) : ?>
         <tr>
            <td><?= $no++; ?></td>
            <td><?= $b["username135"]; ?></td>
            <td><?php echo $b["role135"] == 0 ? "Administrator" : ($b["role135"] == 1 ? 'Direktur' : ($b["role135"] == 2 ? "Kasir" : "unknown")); ?></td>
            <td>
               <a href="?page=user&act=update&id=<?= $b["id_user135"]; ?>" class="btn btn-info btn-xs">Edit</a>
               <a href="?page=user&act=delete&id=<?= $b["id_user135"]; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin Hapus <?= $b["nama_pengunjung"] ?>?')">Hapus</a>
            </td>
         </tr>
         <?php endforeach; ?>
      </tbody>
   </table>
</div>