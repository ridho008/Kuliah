<?php 
$id_user = $_GET['id'];
$user = mysqli_query($con, "DELETE FROM user135 WHERE id_user135 = '$id_user'");
if($user) {
      echo "<script>alert('Data User Berhasil Dihapus.');window.location='?page=user';</script>";
   } else {
      echo "<script>alert('Data User Gagal Dihapus.');window.location='?page=user';</script>";
   }
?>