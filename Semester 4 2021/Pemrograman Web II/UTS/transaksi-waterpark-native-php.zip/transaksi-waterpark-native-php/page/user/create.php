<?php 
if(isset($_POST['add'])) {
   if(storeUser($_POST) > 0) {
      echo "<script>alert('Data User Berhasil Ditambahkan.');window.location='?page=user';</script>";
   } else {
      echo "<script>alert('Data User Gagal Ditambahkan.');window.location='?page=user&act=add';</script>";
   }
}
?>
<h1>Tambah Pengunjung</h1>
<form action="" method="post">
   <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" class="form-control" required="">
   </div>
   <div class="form-group">
      <label for="password">Password</label>
      <input type="password" name="password" id="password" class="form-control" required="">
   </div>
   <div class="form-group">
      <label for="role">Akses</label>
      <select name="role" id="role" class="form-control">
         <option value="">-- Pilih Akses --</option>
         <option value="0">Administrator</option>
         <option value="1">Direktur</option>
         <option value="2">Kasir</option>
      </select>
   </div>
   <div class="form-group">
      <button type="submit" name="add" class="btn btn-primary btn-xs">Tambah</button>
   </div>
</form>