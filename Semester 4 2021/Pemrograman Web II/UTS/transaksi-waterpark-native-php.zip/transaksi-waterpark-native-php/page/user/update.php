<?php 
$id_user = $_GET['id'];
$user = query("SELECT * FROM user135 WHERE id_user135 = '$id_user'")[0];
// var_dump($pengunjung); die;
if(isset($_POST['update'])) {
   if(updateUser($_POST) > 0) {
      echo "<script>alert('Data User Berhasil Diubah.');window.location='?page=user';</script>";
   } else {
      echo "<script>alert('Data User Gagal Diubah.');window.location='?page=user&act=add';</script>";
   }
}
?>
<h1>Edit username <?= $user["username135"]; ?></h1>
<form action="" method="post">
   <input type="hidden" name="id_user" value="<?= $user["id_user135"]; ?>">
   <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" class="form-control" required="" value="<?= $user["username135"]; ?>">
   </div>
   <div class="form-group">
      <label for="password">password</label>
      <input type="password" name="password" id="password" class="form-control" required="">
   </div>
   <div class="form-group">
      <label for="role">Akses</label>
      <select name="role" id="role" class="form-control">
         <option value="">-- Pilih Akses --</option>
         <option value="0" <?= ($user['role135'] == 0) ? "selected" : '' ?>>Administrator</option>
         <option value="1" <?= ($user['role135']) == 1 ? "selected" : '' ?>>Direktur</option>
         <option value="2" <?= ($user['role135']) == 2 ? "selected" : '' ?>>Kasir</option>
      </select>
   </div>
   <div class="form-group">
      <button type="submit" name="update" class="btn btn-primary btn-xs">Ubah</button>
   </div>
</form>