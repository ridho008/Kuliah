<?php 
$pengunjung = query("SELECT * FROM pengunjung135 ORDER BY id_pengunjung135 DESC");
?>
<h1>Pengunjung</h1>
<a href="?page=pengunjung&act=add" class="btn btn-primary mb-2">Tambah Pengunjung</a>
<div class="table-responsive">
   <table class="table table-bordered table-striped">
      <thead class="bg-dark text-light">
         <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Aksi</th>
         </tr>
      </thead>
      <tbody>
         <?php $no = 1; foreach($pengunjung as $b) : ?>
         <tr>
            <td><?= $no++; ?></td>
            <td><?= $b["nama_pengunjung135"]; ?></td>
            <td>
               <a href="?page=pengunjung&act=update&id=<?= $b["id_pengunjung135"]; ?>" class="btn btn-info btn-xs">Edit</a>
               <a href="?page=pengunjung&act=delete&id=<?= $b["id_pengunjung135"]; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Yakin Hapus <?= $b["nama_pengunjung"] ?>?')">Hapus</a>
            </td>
         </tr>
         <?php endforeach; ?>
      </tbody>
   </table>
</div>