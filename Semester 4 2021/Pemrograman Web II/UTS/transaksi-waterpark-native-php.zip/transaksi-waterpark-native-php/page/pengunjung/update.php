<?php 
$id_pengunjung = $_GET['id'];
$pengunjung = query("SELECT * FROM pengunjung135 WHERE id_pengunjung135 = '$id_pengunjung'")[0];
// var_dump($pengunjung); die;
if(isset($_POST['update'])) {
   if(updatePengunjung($_POST) > 0) {
      echo "<script>alert('Data Pengunjung Berhasil Diubah.');window.location='?page=pengunjung';</script>";
   } else {
      echo "<script>alert('Data Pengunjung Gagal Diubah.');window.location='?page=pengunjung&act=add';</script>";
   }
}
?>
<h1>Edit Pengunjung <?= $pengunjung["nama_pengunjung135"]; ?></h1>
<form action="" method="post">
   <input type="hidden" name="id_pengunjung" value="<?= $pengunjung["id_pengunjung135"]; ?>">
   <div class="form-group">
      <label for="nama">Nama Pengunjung</label>
      <input type="text" name="nama" id="nama" class="form-control" required="" value="<?= $pengunjung["nama_pengunjung135"]; ?>">
   </div>
   <div class="form-group">
      <button type="submit" name="update" class="btn btn-primary btn-xs">Ubah</button>
   </div>
</form>