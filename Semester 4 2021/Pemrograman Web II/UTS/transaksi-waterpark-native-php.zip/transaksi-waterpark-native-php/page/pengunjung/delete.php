<?php 
$id_pengunjung = $_GET['id'];
$pengunjung = mysqli_query($con, "DELETE FROM pengunjung135 WHERE id_pengunjung135 = '$id_pengunjung'");
if($barang) {
      echo "<script>alert('Data Pengunjung Berhasil Dihapus.');window.location='?page=pengunjung';</script>";
   } else {
      echo "<script>alert('Data Pengunjung Gagal Dihapus.');window.location='?page=pengunjung';</script>";
   }
?>