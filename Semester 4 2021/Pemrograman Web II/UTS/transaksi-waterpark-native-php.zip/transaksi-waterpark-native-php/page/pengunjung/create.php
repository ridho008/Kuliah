<?php 
if(isset($_POST['add'])) {
   if(storePengunjung($_POST) > 0) {
      echo "<script>alert('Data Barang Berhasil Ditambahkan.');window.location='?page=pengunjung';</script>";
   } else {
      echo "<script>alert('Data Pengunjung Gagal Ditambahkan.');window.location='?page=pengunjung&act=add';</script>";
   }
}
?>
<h1>Tambah Pengunjung</h1>
<form action="" method="post">
   <div class="form-group">
      <label for="nama">Nama Pengunjung</label>
      <input type="text" name="nama" id="nama" class="form-control" required="">
   </div>
   <div class="form-group">
      <button type="submit" name="add" class="btn btn-primary btn-xs">Tambah</button>
   </div>
</form>