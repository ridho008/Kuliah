<?php

// jika button tampilkan diklik
if (isset($_POST['tampilkan'])) {
   // $fuldate=$_POST['tahun'].'-'.$_POST['bulan'].'-'.$_POST['tanggal'];
   // var_dump($fuldate); die;
   if (($_POST['tanggal']!='')&&($_POST['bulan']=='')&&($_POST['tahun']=='')) {
      // tanggal
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE SUBSTRING(transaksi135.tgl_transaksi135,9,2)='$_POST[tanggal]' ORDER BY transaksi135.id_transaksi135 ASC  "); 
   }else if (($_POST['tanggal']=='')&&($_POST['bulan']!='')&&($_POST['tahun']=='')) {
      //bulan
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE SUBSTRING(transaksi135.tgl_transaksi135,6,2)='$_POST[bulan]' ORDER BY transaksi135.id_transaksi135 ASC "); 
   }else if (($_POST['tanggal']=='')&&($_POST['bulan']=='')&&($_POST['tahun']!='')) {
      //tahun
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE LEFT(transaksi135.tgl_transaksi135,4)='$_POST[tahun]' ORDER BY transaksi135.id_transaksi135 ASC "); 
   }else if (($_POST['tanggal']!='')&&($_POST['bulan']!='')&&($_POST['tahun']=='')) {
      //tanggal dan bulan
      $bt=$_POST['bulan'].'-'.$_POST['tanggal'];
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE SUBSTRING(transaksi135.tgl_transaksi135,6,5)='$bt' ORDER BY transaksi135.id_transaksi135 ASC "); 
   }else if (($_POST['tanggal']=='')&&($_POST['bulan']!='')&&($_POST['tahun']!='')) {
      //bulan dan tahun
      $bt=$_POST['tahun'].'-'.$_POST['bulan'];
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE SUBSTRING(transaksi135.tgl_transaksi135,1,7)='$bt' ORDER BY transaksi135.id_transaksi135 ASC "); 
      // jika tangganya berisi, dan bulannya ada isinya juga, dan tahunnya ada isinya
   }else if (($_POST['tanggal']!='')&&($_POST['bulan']!='')&&($_POST['tahun']!='')) {
      //tanggal, bulan dan tahun 
      $fuldate=$_POST['tahun'].'-'.$_POST['bulan'].'-'.$_POST['tanggal'];
      $q=mysqli_query($con,"SELECT * FROM `transaksi135` INNER JOIN pengunjung135 ON transaksi135.id_pengunjung135=pengunjung135.id_pengunjung135 INNER JOIN tiket135 ON transaksi135.id_tiket135=tiket135.id_tiket135 WHERE SUBSTRING(transaksi135.tgl_transaksi135,1,10)='$fuldate' ORDER BY transaksi135.id_transaksi135 ASC "); 
   } else {
      $fuldate=$_POST['tahun'].'-'.$_POST['bulan'].'-'.$_POST['tanggal'];
      $q=mysqli_query($con,"SELECT * FROM transaksi135 JOIN pengunjung135 ON transaksi135.id_pengunjung135 = pengunjung135.id_pengunjung135 JOIN tiket135 ON transaksi135.id_tiket135 = tiket135.id_tiket135 ORDER BY transaksi135.id_transaksi135 ASC"); 
   }
}else{
   $q=mysqli_query($con,"SELECT * FROM transaksi135 JOIN pengunjung135 ON transaksi135.id_pengunjung135 = pengunjung135.id_pengunjung135 JOIN tiket135 ON transaksi135.id_tiket135 = tiket135.id_tiket135 ORDER BY transaksi135.id_transaksi135 ASC"); 
}

?>
<div class="row">
   <div class="col-md-6">
      <div class="alert alert-info">
         <small><strong>Note : cara menggunakan</strong></small><br>
         <small>1. untuk menampilkan berdasarkan tanggal maka bulan dan tahun di kosongkan</small><br>
         <small>2. untuk menampilkan berdasarkan bulan maka tanggal dan tahun di kosongkan</small><br>
         <small>3. untuk menampilkan berdasarkan tahun maka bulan dan tanggal di kosongkan</small><br>
         <small>4. untuk menampilkan berdasakan tanggal yang lengkap silahkan di isi semua form</small>
      </div>
   </div>
   <div class="col-md-6">
      <div class="alert alert-warning">
         <small class="font-weight-bold">Jika ingin mencari tanggal dan bulan dari 1 hingga 9, Pastikan tambahkan 0 didepan. <br>
         <i>Cth Tanggal : 03, Bulan : 09</i></small>
      </div>
   </div>
   <div class="col-md-12">
      <form action="index.php?page=filterLaporan" method="post">
         <table class="table">
            <tr>
               <td>Tanggal</td>
               <td>
                  <input type="text" name="tanggal" class="form-control" value="<?= ($_POST['tanggal']) ? $_POST['tanggal'] : ''; ?>" placeholder="tanggal">
               </td>
               <td>Bulan</td>
               <td>
                  <input type="text" name="bulan" class="form-control" value="<?= ($_POST['bulan']) ? $_POST['bulan'] : ''; ?>" placeholder="bulan">
               </td>
               <td>Tahun</td>
               <td>
                  <input type="text" name="tahun" class="form-control" value="<?= ($_POST['tahun']) ? $_POST['tahun'] : ''; ?>" placeholder="tahun">
               </td>
               <td>
                  <button type="submit" class="btn btn-primary" name="tampilkan">Tampilkan</button>
               </td>
            </tr>
         </table>
      </form>
   </div>
</div>
<span>Tanggal : <?= ($_POST['tanggal']) ? $_POST['tanggal'] : '0'; ?></span>
<span>Bulan : <?= ($_POST['bulan']) ? $_POST['bulan'] : '0'; ?></span>
<span>Tahun : <?= ($_POST['tahun']) ? $_POST['tahun'] : '0';; ?></span>
<table class="table table-bordered table-striped">
   <thead class="bg-dark text-light">
      <tr>
         <th>No</th>
         <th>Pembeli</th>
         <th>Buah</th>
         <th>Harga/Kg</th>
         <th>Jumlah Beli</th>
         <th>Total Barang</th>
         <th>Diskon</th>
         <th>Total</th>
      </tr>
   </thead>
   <tbody>
      <?php $no = 1; while($r = mysqli_fetch_assoc($q)) : ?>
      <?php 
      $diskon10 = 10;
      $diskon20 = 20;
      @$totalBarang += $r["jml_tiket135"] * $r["harga135"];
      ?>
      <tr>
         <td><?= $no++; ?></td>
         <td><?= $r["nama_pengunjung135"]; ?></td>
         <td><?= $r["nama_tiket135"]; ?></td>
         <td><?= number_format($r["harga135"],0 ,',', '.'); ?></td>
         <td><?= $r["jml_tiket135"]; ?> Kg</td>
         <td><?= number_format($r["jml_tiket135"] * $r["harga135"],0 ,',', '.') ?></td>
         <td>
            <?php if($r["jml_tiket135"] >= 10 && $r["jml_tiket135"] <= 19) : ?>
               <?php $totDiskon = ($diskon10 / 100) * $r["jml_tiket135"] * $r["harga135"]; ?>
               <?= number_format($totDiskon, 0, ',', '.') . ' 10%'; ?>
               <?php elseif($r["jml_tiket135"] <= 9) : ?>
                  <span class="badge badge-info">Maksimal 10Kg mendapatkan diskon.</span>
            <?php endif; ?>

            <?php if($r["jml_tiket135"] >= 20) : ?>
               <?php $totDiskon = ($diskon20 / 100) * $r["jml_tiket135"] * $r["harga135"]; ?>
               <?= number_format($totDiskon, 0, ',', '.') . ' 20%'; ?>
            <?php endif; ?>
         </td>
         <td>
            <?php if($r["jml_tiket135"] >= 10 || $r["jml_tiket135"] <= 19 || $r["jml_tiket135"] >= 20) : ?>
               <?php @$totalBarangSemua += $totDiskon - ($r["jml_tiket135"] * $r["harga135"]) ?>
            <?= number_format(abs($totDiskon - ($r["jml_tiket135"] * $r["harga135"])),0 ,',', '.') ?>
            <?php elseif($r["jml_tiket135"] >= 0 || $r["jml_tiket135"] <= 9): ?>
               <?= $r["jml_tiket135"] * $r["harga135"] ?>
            <?php endif; ?>
         </td>
      </tr>
      <?php endwhile; ?>
   </tbody>
   <tfoot>
      <tr>
         <td colspan="6" class="text-center">Total Tiket Dibeli <strong><?= number_format($totalBarang, 0, ',', '.') ?></strong></td>
         <td colspan="2" class="text-center">Total Keseluruhan <strong><?= number_format(abs($totalBarangSemua), 0, ',', '.') ?></strong></td>
      </tr>
   </tfoot>
   
</table>