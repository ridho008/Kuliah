<?php 
$transaksi = query("SELECT * FROM transaksi135 JOIN pengunjung135 ON transaksi135.id_pengunjung135 = pengunjung135.id_pengunjung135 JOIN tiket135 ON tiket135.id_tiket135 = transaksi135.id_tiket135 ORDER BY transaksi135.id_tiket135 DESC");

?>
<h1 class="text-center">Laporan Tiket WaterPark</h1>
<table class="table table-bordered table-striped">
   <thead class="bg-dark text-light">
      <tr>
         <th>No</th>
         <th>Pembeli</th>
         <th>Buah</th>
         <th>Harga/Kg</th>
         <th>Jumlah Beli</th>
         <th>Total Barang</th>
         <th>Diskon</th>
         <th>Total</th>
      </tr>
   </thead>
   <tbody>
      <?php $no = 1; foreach($transaksi as $t) : ?>
      <?php 
      $diskon10 = 10;
      $diskon20 = 20;
      @$totalBarang += $t["jml_tiket135"] * $t["harga135"];
      ?>
      <tr>
            <td><?= $no++; ?></td>
            <td><?= $t["nama_pengunjung135"]; ?></td>
            <td><?= $t["nama_tiket135"]; ?></td>
            <td><?= number_format($t["harga135"],0 ,',', '.'); ?></td>
            <td><?= $t["jml_tiket135"]; ?> Kg</td>
            <td><?= number_format($t["jml_tiket135"] * $t["harga135"],0 ,',', '.') ?></td>
            <td>
               <?php if($t["jml_tiket135"] >= 10 && $t["jml_tiket135"] <= 19) : ?>
                  <?php $totDiskon = ($diskon10 / 100) * $t["jml_tiket135"] * $t["harga135"]; ?>
                  <?= number_format($totDiskon, 0, ',', '.') . ' 10%'; ?>
                  <?php elseif($t["jml_tiket135"] <= 9) : ?>
                     <span class="badge badge-info">Maksimal 10Kg mendapatkan diskon.</span>
               <?php endif; ?>

               <?php if($t["jml_tiket135"] >= 20) : ?>
                  <?php $totDiskon = ($diskon20 / 100) * $t["jml_tiket135"] * $t["harga135"]; ?>
                  <?= number_format($totDiskon, 0, ',', '.') . ' 20%'; ?>
               <?php endif; ?>
            </td>
            <td>
               <?php if($t["jml_tiket135"] >= 10 || $t["jml_tiket135"] <= 19 || $t["jml_tiket135"] >= 20) : ?>
                  <?php @$totalBarangSemua += $totDiskon - ($t["jml_tiket135"] * $t["harga135"]) ?>
               <?= number_format(abs($totDiskon - ($t["jml_tiket135"] * $t["harga135"])),0 ,',', '.') ?>
               <?php elseif($t["jml_tiket135"] >= 0 || $t["jml_tiket135"] <= 9): ?>
                  <?= $t["jml_tiket135"] * $t["harga135"] ?>
               <?php endif; ?>
            </td>
         </tr>
      <?php endforeach; ?>
   </tbody>
   <tfoot>
      <tr>
         <td colspan="6" class="text-center">Total Tiket Dibeli <strong><?= number_format($totalBarang, 0, ',', '.') ?></strong></td>
         <td colspan="2" class="text-center">Total Keseluruhan <strong><?= number_format(abs($totalBarangSemua), 0, ',', '.') ?></strong></td>
      </tr>
   </tfoot>
</table>

<script>
   window.print();
</script>