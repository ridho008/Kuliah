# Aplikasi Transaksi Tiket Sederhana WaterPark PHP

## Apa Saja Fiturnya ?
- Crud User
- Crud Pengunjung
- Crud Transaksi
- Crud Tiket
- Filter Laporan (Tanggal, Bulan, Tahun)
- Login & Logout
- Cetak Laporan Default

### UTS Programming Website II (Kuliah)

Aplikasi ini adalah tugas dari dosen yaitu UTS mata kuliah programming website II.