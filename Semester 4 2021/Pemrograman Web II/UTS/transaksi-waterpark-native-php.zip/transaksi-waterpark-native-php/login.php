<?php 
session_start();
if(isset($_SESSION['nama'])) {
  header("Location: index.php");
  exit;
}
require 'config/connect.php';
if(isset($_POST['masuk'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $user = mysqli_query($con, "SELECT * FROM user135 WHERE username135 = '$username'") or die(mysqli_error($con));
  /*
    0 = Administrator -> Akses semua halaman
    1 = Direktur -> Menampilkan hasil laporan saja
    2 = Kasir -> Akses Transaksi & Laporan
  */
  if($user != null) {
    $userAda = mysqli_num_rows($user);
    $row = mysqli_fetch_assoc($user);
    if($userAda > 0) {
      $_SESSION['username'] = $row['username135'];
      $_SESSION['role'] = $row['role135'];

      if($row['role135'] == 0) {
        header("Location: index.php");
      } else if($row['role135'] == 1) {
        header("Location: index.php");
      } else if($row['role135'] == 2) {
        header("Location: index.php");
      }
    }
  }
}


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Login - WaterPark</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/sign-in/">
    <style>
      body {
        background-image: url('assets/img/waterpark.jpg');
        background-position: center;
        background-attachment: fixed;
        background-size: cover;
        background-repeat: no-repeat;
      }
    </style>

    <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4" style="margin: 150px auto;">
        <form action="" method="post">
          <div class="card">
            <div class="card-header text-center bg-dark text-light"><h5>Login WaterPark</h5></div>
            <div class="card-body">
              <h1 class="h3 mb-3 font-weight-normal"></h1>
              <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" placeholder="Nama Pengunjung" required autofocus>
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
              </div>
              <button name="masuk" class="btn btn-lg btn-dark btn-block" type="submit">Masuk</button>
              
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>

