<?php 
require 'connect.php';

function query($sql)
{
   global $con;
   $query = mysqli_query($con, $sql) or die(mysqli_error($con));
   $rows = [];
   while ($row = mysqli_fetch_assoc($query)) {
      $rows[] = $row;
   }
   return $rows;
}

function storeUser($data)
{
   global $con;
   $username = htmlspecialchars($data["username"]);
   $password = htmlspecialchars($data["password"]);
   $role = htmlspecialchars($data["role"]);

   mysqli_query($con, "INSERT INTO user135 VALUES(null, '$username', '$password', '$role')") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function updateUser($data)
{
   global $con;
   $id_user = htmlspecialchars($data["id_user"]);
   $username = htmlspecialchars($data["username"]);
   $password = htmlspecialchars($data["password"]);
   $role = htmlspecialchars($data["role"]);

   mysqli_query($con, "UPDATE user135 SET username135 = '$username', password135 = '$password', role135 = '$role' WHERE id_user135 = $id_user") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function storePengunjung($data)
{
   global $con;
   $nama = htmlspecialchars($data["nama"]);

   mysqli_query($con, "INSERT INTO pengunjung135 VALUES(null, '$nama')") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function updatePengunjung($data)
{
   global $con;
   $id_pengunjung = htmlspecialchars($data["id_pengunjung"]);
   $nama = htmlspecialchars($data["nama"]);

   mysqli_query($con, "UPDATE pengunjung135 SET nama_pengunjung135 = '$nama' WHERE id_pengunjung135 = $id_pengunjung") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function storeTiket($data)
{
   global $con;
   $tiket = htmlspecialchars($data["tiket"]);
   $harga = htmlspecialchars($data["harga"]);
   $deskripsi = htmlspecialchars($data["deskripsi"]);

   mysqli_query($con, "INSERT INTO tiket135 VALUES(null, '$tiket', '$harga', '$deskripsi')") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function updateTiket($data)
{
   global $con;
   $id_tiket = htmlspecialchars($data["id_tiket"]);
   $tiket = htmlspecialchars($data["tiket"]);
   $harga = htmlspecialchars($data["harga"]);
   $deskripsi = htmlspecialchars($data["deskripsi"]);

   mysqli_query($con, "UPDATE tiket135 SET nama_tiket135 = '$tiket', harga135 = '$harga', deskripsi135 = '$deskripsi' WHERE id_tiket135 = $id_tiket") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function storeTransaksi($data)
{
   global $con;
   $pengunjung = htmlspecialchars($data["pengunjung"]);
   $tiket = htmlspecialchars($data["tiket"]);
   $jml_tiket = htmlspecialchars($data["jml_tiket"]);
   $tgl_transaksi = date('Y-m-d H:i:s');

   mysqli_query($con, "INSERT INTO transaksi135 VALUES(null, '$tiket', '$pengunjung', '$jml_tiket', '$tgl_transaksi')") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}

function updateTransaksi($data)
{
   global $con;
   $id_transaksi = htmlspecialchars($data["id_transaksi"]);
   $pengunjung = htmlspecialchars($data["pengunjung"]);
   $tiket = htmlspecialchars($data["tiket"]);
   $jml_tiket = htmlspecialchars($data["jml_tiket"]);

   mysqli_query($con, "UPDATE transaksi135 SET id_tiket135 = '$tiket', id_pengunjung135 = '$pengunjung', jml_tiket135 = '$jml_tiket' WHERE id_transaksi135 = $id_transaksi") or die(mysqli_error($con));
   return mysqli_affected_rows($con);
}