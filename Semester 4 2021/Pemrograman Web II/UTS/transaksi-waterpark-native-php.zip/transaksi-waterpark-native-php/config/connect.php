<?php 
$con = mysqli_connect("localhost", "root", "", "water-part-native-135") or die(mysqli_error($con));

?>